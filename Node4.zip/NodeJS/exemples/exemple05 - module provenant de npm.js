const avecDeLaCouleurCestMieux = require('colors');

let texteBlanc = avecDeLaCouleurCestMieux.rainbow('Salut les amis !!!!');

console.log(texteBlanc);

