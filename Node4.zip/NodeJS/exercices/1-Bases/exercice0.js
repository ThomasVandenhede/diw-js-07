/**
  Ce programme en JavaScript affiche 100 fois un message dans la console
  Pour l'utiliser on écrira : node exercice0.js à partir du dossier dans
  lequel se trouve le fichier.
**/
for(var i = 0; i < 100; i++){
  console.log('Bonjour ' + i + ' fois !');
}

/**
  Exercices :

    1. Exécutez ce programme avec Node JS.
**/